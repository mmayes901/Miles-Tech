<?php /* Template Name: Vescor Sitemap template */ ?>
<?php get_header(); ?>

<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>
<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>

<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section>
			<div class="row animated zoomIn">
				<div class="large-12 columns">
			    	<h1 class="pgtitle"><?php the_title(); ?></h1>
			    </div>
		    </div>
		</section>

<!-- Offset Section -->		
		<section></section>

<!-- Content Section UnShaded  -->
		<section class="padT60 padB60">
				<div class="row">
					
					<div class=" medium-6 columns mobileCenter black text-center">
						<ul>
							<li><a href="/pipeline/">Pipeline</a></li>
							<li><a href="/management/">Management</a></li>
							<li><a href="/board/">Board</a></li>
						</ul>
					</div>
					<div class=" medium-6 columns mobileCenter black text-center">
							<ul>
							<li><a href="/our-partners/">Our Partners</a></li>
							<li><a href="/news/">News</a></li>
							<li><a href="/contact-us/">Contact Us</a></li>
						</ul>
					</div>
	
				</div>
		</section>

<!-- Offset Section -->		
		<section></section>
</div>
<?php get_footer(); ?>
