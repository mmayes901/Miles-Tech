<?php get_header(); ?>

<div id="content" role="main">


<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>


<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section class="padT10 PadB20">
			<div class="row animated zoomIn">
				<div class="large-12 columns">
			    	<h1 class="pgtitle">News</h1>
			    </div>
		    </div>
		</section>

	<div id="entries" class="padT20 padB60">
		<div class="row">
			<div class="medium-12 columns">
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'entry' ); ?>
				<?php endwhile; endif; ?>
				<footer class="footer">
				<?php get_template_part( 'nav', 'below-single' ); ?>
				</footer>
				</section>
			</div>
		</div>
	</div>	
<?php //get_sidebar(); ?>
<?php get_footer(); ?>