<?php /* Template Name: Vescor default template */ ?>
<?php get_header(); ?>
<?php 
		$first_title = get_field('first_title', $post->ID);
		$first_section_text = get_field('first_section_text', $post->ID);
		$first_image = get_field('first_image', $post->ID);
		$first_alt_text = get_field('first_alt_text', $post->ID);
?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>
<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>

<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section>
			<div class="row animated zoomIn">
				<div class="large-12 columns">
			    	<h1 class="pgtitle"><?php the_title(); ?></h1>
			    </div>
		    </div>
		</section>

<!-- Offset Section -->		
		<section></section>

<!-- Content Section UnShaded  -->
		<section class="padT60 padB60">
				<div class="row">
					
					<div class=" medium-9 columns">
						<?php the_field('first_title'); ?>
								<br>
                        		<?php the_field('first_section_text'); ?>
						</p>
					</div>
					<div class=" medium-3 columns">
						<img src="<?php the_field('first_image'); ?>" alt="<?php the_field('first_alt_text') ?>">
					</div>
	
				</div>
		</section>

<!-- Offset Section -->		
		<section></section>
</div>
<?php get_footer(); ?>
