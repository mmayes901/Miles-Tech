<?php get_header(); ?>

<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>


<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>


<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section class="padT10 PadB20">
			<div class="row animated zoomIn">
				<div class="large-12 columns">
			    	<h1 class="pgtitle">News</h1>
			    </div>
		    </div>
		</section>
		<!-- Offset Section -->		
		<section></section>


	<div id="entries" class="padT20 padB60">
		<div class="row">
			<div class="medium-8 columns">
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<?php get_template_part( 'entry' ); ?>
					<?php //comments_template(); ?>
				<?php endwhile; endif; ?>
				<?php get_template_part( 'nav', 'below' ); ?>
			</div>
			<div class="medium-4 columns">
				<?php get_sidebar(); ?>
			</div>
		</div>
	</div>
<?php get_footer(); ?>