<?php if ( !is_front_page() ) {	
		echo '<div class="smScientistBg">

		</div>'; 
} ?>
