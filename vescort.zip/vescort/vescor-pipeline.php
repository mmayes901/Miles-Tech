<?php /* Template Name: Vescor pipeline template */ ?>
<?php get_header(); ?>
<?php 
?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>


<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>
<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section class="padT10 PadB20">
			<div class="row animated zoomIn">
				<div class="large-12 columns">
			    	<h1 class="pgtitle"><?php the_title(); ?></h1>
			    </div>
		    </div>
		</section>

<!-- Offset Section -->		
		<section></section>


<!-- Content Section UnShaded  -->
		<section id="pipeline1">
				<div class="row"> 
					
					<div class=" medium-12 columns">
						<h3><?php the_field('pipeline1_title'); ?></h3>		
                       	<?php the_field('pipeline1_section_text'); ?>
                       	
					</div>
	
				</div>
		</section>

<!-- Content Section Shaded  -->
		<section id="pipeline2" class="MarginT50 padT60 padB40">
				<div class="row">
					
					<div class=" medium-12 columns">
						<h3><?php the_field('pipeline2_title'); ?></h3>		
						 <?php the_field('pipeline2_section_text'); ?> 
					</div>
	
				</div>
		</section>
	
</div>
<?php get_footer(); ?>
