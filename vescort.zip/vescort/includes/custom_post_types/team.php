<?php
	function custom_post_type__team() {
		// Set UI labels for Custom Post Type
		$labels = array(
			'name'                => _x( 'Team Members', 'Post Type General Name', 'mileswpfet' ),
			'singular_name'       => _x( 'Team Member', 'Post Type Singular Name', 'mileswpfet' ),
			'menu_name'           => __( 'Team Members', 'mileswpfet' ),
			'parent_item_colon'   => __( 'Parent Team Member', 'mileswpfet' ),
			'all_items'           => __( 'All Team Members', 'mileswpfet' ),
			'view_item'           => __( 'View Team Member', 'mileswpfet' ),
			'add_new_item'        => __( 'Add New Team Member', 'mileswpfet' ),
			'add_new'             => __( 'Add New', 'mileswpfet' ),
			'edit_item'           => __( 'Edit Team Member', 'mileswpfet' ),
			'update_item'         => __( 'Update Team Member', 'mileswpfet' ),
			'search_items'        => __( 'Search Team Member', 'mileswpfet' ),
			'not_found'           => __( 'Not Found', 'mileswpfet' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'mileswpfet' ),
		);
		// Set other options for Custom Post Type
		$args = array(
			'label'               => __( 'Team Members', 'mileswpfet' ),
			'description'         => __( 'Team Member news and reviews', 'mileswpfet' ),
			'labels'              => $labels,
			'supports'            => array( 'title', 'editor', 'revisions', 'custom-fields', ),
			'taxonomies'          => array(),
			'hierarchical'        => false,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 5,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
			'rewrite' 			  => array('slug' => 'team'),
		);
		// Registering your Custom Post Type
		register_post_type( 'team_members', $args );
	}
	add_action( 'init', 'custom_post_type__team', 0 );