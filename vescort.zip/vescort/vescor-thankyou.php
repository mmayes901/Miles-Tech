<?php /* Template Name: Vescor Thank You Template */ ?>
<?php get_header(); ?>
<?php 
		$first_title = get_field('first_title', $post->ID);
		$first_section_text = get_field('first_section_text', $post->ID);
		$first_image = get_field('first_image', $post->ID);
		$first_alt_text = get_field('first_alt_text', $post->ID);
?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>
<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>
<!-- Offset Section -->		
		<section></section>

		<section class="padT60 padB60">
				<div class="row">
					
					<div class=" medium-12 columns mobileCenter text-center" style="margin: 0 auto;">
						<img src="/wp-content/uploads/2017/03/thankyou.png" alt="Thank you for inquirying about Vescor Therapeutics, LLC.">
					</div>
				<div class="row">
					
					<div class=" medium-12 columns mobileCenter text-center" style="margin: 0 auto;">
							<h6 class="text-center"> Thank you for your inquiry! It has been successfully submitted and will be addressed accordingly. </h6>
					</div>
	
				</div>
		</section>

<!-- Offset Section -->		
		<section></section>
</div>
<?php get_footer(); ?>




