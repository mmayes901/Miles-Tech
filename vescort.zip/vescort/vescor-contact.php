<?php /* Template Name: Vescor contact template */ ?>
<?php get_header(); ?>
<?php 
?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>

<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>
<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section>
			<div class="row animated zoomIn">
				<div class="large-12 columns">
			    	<h1 class="pgtitle"><?php the_title(); ?></h1>
			    </div>
		    </div>
		</section>

<!-- Offset Section -->		
		<section></section>


<!-- Content Section UnShaded  -->
		<section id="contactUs" class="padT60 padB60">
				<div class="row">
					<div class=" medium-4 columns text-center" style="vertical-align: baseline;">
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<img src="/wp-content/uploads/2017/03/Google-Maps.png" height="156px" width="156px">
						<p>
						<strong>Vescor Therapeutics, LLC</strong> <br />
						780 Third Ave. <br />
						New York, New York 10017
						</p>
					</div>

					<div class=" medium-4 columns mobileCenter">
						<?php
							if ( function_exists( 'ninja_forms_display_form' ) ) {
							  ninja_forms_display_form( 1 );
							}
						?>
					</div>
					<div class=" medium-4 columns text-center mobileCenter">
					<p>&nbsp;</p>
					<p>&nbsp;</p>
					<p>&nbsp;</p>
					<p>&nbsp;</p>
						<a href="https://www.google.com/maps/dir//780+3rd+Ave,+New+York,+NY+10017/@40.7550393,-73.9740528,17z/data=!4m16!1m7!3m6!1s0x89c258fd36e72881:0x45071588ea02e7ff!2s780+3rd+Ave,+New+York,+NY+10017!3b1!8m2!3d40.7550353!4d-73.9718588!4m7!1m0!1m5!1m1!1s0x89c258fd36e72881:0x45071588ea02e7ff!2m2!1d-73.9718588!2d40.7550353" target="_blank" style="border: 0;"><img src="/wp-content/uploads/2017/03/vescorMap.png" alt="Vescor Therapeutics, LLC., New York City Location"></a><br>
						Click map for directions
					</div>
	
				</div>
		</section>

<!-- Content Section Shaded  -->
<!--
		<section id="elements" class="padT60 padB60">
				<div class="row">
					
					<div class=" medium-6 columns">
						<img src="<?php the_field('second_image'); ?>" alt="<?php the_field('second_alt_text') ?>">
					</div>
					<div class=" medium-6 columns">
							<?php the_field('second_title'); ?>		
									<br>
		                         	<?php the_field('second_section_text'); ?>
					</div>
	
				</div>
		</section>

-->

<!-- Offset Section -->		
		<section></section>

</div>
<?php get_footer(); ?>
