<?php /* Template Name: Vescor blank template */ ?>
<?php get_header(); ?>
<?php 
?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>

<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>
<!-- Offset Section -->		
		<section></section>



<!-- Page Title  -->
	 	<section id="elements">
			<div class="row">
				<div class="large-12 columns">
			    	<h1 style="text-align: center; margin: -150px auto; background-color: white; width: 300px; border: 2px solid black; opacity: 0.8;"><?php the_title(); ?></h1>
			    </div>
		    </div>
		</section>

<!-- Offset Section -->		
		<section></section>

<!-- Content Section UnShaded  -->
		<section id="elements" class="padT60 padB60">
				<div class="row">
					
					<div class=" medium-6 columns">
						<?php the_field('first_title'); ?>
								<br>
                        		<?php the_field('first_section_text'); ?>
						</p>
					</div>
					<div class=" medium-6 columns">
						<img src="<?php the_field('first_image'); ?>" alt="<?php the_field('first_alt_text') ?>">
					</div>
	
				</div>
		</section>

<!-- Content Section Shaded  -->
<!--
		<section id="elements" class="padT60 padB60">
				<div class="row">
					
					<div class=" medium-6 columns">
						<img src="<?php the_field('second_image'); ?>" alt="<?php the_field('second_alt_text') ?>">
					</div>
					<div class=" medium-6 columns">
							<?php the_field('second_title'); ?>		
									<br>
		                         	<?php the_field('second_section_text'); ?>
					</div>
	
				</div>
		</section>

-->

<!-- Offset Section -->		
		<section></section>

<!-- How Can We Make A Difference -->

		<section>
			<div class="row helper wrapper">
				<div class="row">
					
				<div class="large-12 columns">
			    	<h3 style="text-align: center; margin: 50px auto; background-color: white; width: 750px; border: 2px solid black; opacity: 0.8;">HOW CAN YOU HELP MAKE A DIFFERENCE?</h3>
			    </div>
				<div class="row">
					<p>&nbsp;</p>
					<div class="small-12 columns" style="text-align: center;"><button type="button" class=" hollow button">FIND OUT MORE</button></div>
				</div>

			</div>
		</section>		
		
	
</div>
<?php get_footer(); ?>
