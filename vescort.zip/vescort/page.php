<?php get_header(); ?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<section id="elements" class="padT60 padB60">
			<div class="row">
				<div class="columns medium-12">
			    	<h1><?php the_title(); ?></h1>
			    </div>
		    </div>
		    <div class="row padT40 padB40">
		    	<div class="columns medium-12">
		    		<div><?php the_content(); ?></div>
		    	</div>
		    </div>
		</section>
	<?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>