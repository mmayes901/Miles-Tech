<?php /* Template Name: Vescor Board Template */ ?>
<?php get_header(); ?>
<?php 
		$first_title = get_field('first_title', $post->ID);
		$first_section_text = get_field('first_section_text', $post->ID);
		$first_image = get_field('first_image', $post->ID);
		$first_alt_text = get_field('first_alt_text', $post->ID);
?>
<?php 
global $more;
$more = 0;
?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>
<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>

<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section>
			<div class="row animated zoomIn">
				<div class="large-12 columns">
			    	<h1 class="pgtitle"><?php the_title(); ?></h1>
			    </div>
		    </div>
		</section>

<!-- Offset Section -->		
		<section></section>

<!-- Content Section UnShaded  -->
		<section id="about1" class="padT60 padB60">
				<div class="row" data-equalizer="about1">
					
					<div class=" medium-9 columns" data-equalizer-watch="about1">
						<h5><?php the_field('first_title'); ?></h5>
						<?php the_field('first_section_text'); ?>
					 
					</div>
					<div class=" medium-3 columns">
						<img src="<?php the_field('first_image'); ?>" alt="<?php the_field('first_alt_text') ?>">
					</div>
	
				</div>
		</section>

<!-- Content Section Shaded  -->
		<section id="about2" class="padT60 padB60">
				<div class="row" data-equalizer="about2">
					
					<div class=" medium-3 columns" data-equalizer-watch="about2">
						<img src="<?php the_field('second_image'); ?>" alt="<?php the_field('second_alt_text') ?>">
					</div>
					<div class=" medium-9 columns" data-equalizer-watch="about2">
							<h5><?php the_field('second_title'); ?>	</h5>	
								<?php the_field('second_section_text'); ?>
					</div>
	
				</div>
		</section>

<!-- Content Section UnShaded  -->
		<section id="about3" class="padT60 padB60">
				<div class="row" data-equalizer="about3">
					
					<div class=" medium-9 columns" data-equalizer-watch="about3">
							<h5><?php the_field('third_title'); ?></h5>		
							<?php the_field('third_section_text'); ?>
					</div>
	
					<div class=" medium-3 columns" data-equalizer-watch="about3">
						<img src="<?php the_field('third_image'); ?>" alt="<?php the_field('third_alt_text') ?>">
					</div>
	
				</div>
		</section>

<!-- Content Section Shaded  -->
		<section id="about4" class="padT60 padB60">
				<div class="row" data-equalizer="about4">
					
					<div class=" medium-3 columns" data-equalizer-watch="about4">
						<img src="<?php the_field('fourth_image'); ?>" alt="<?php the_field('fourth_alt_text') ?>">
					</div>
					<div class=" medium-9 columns" data-equalizer-watch="about4">
							<h5><?php the_field('fourth_title'); ?></h5>
							<?php the_field('fourth_section_text'); ?>
					</div>
	
				</div>
		</section>

<?php the_content('Continue Reading'); ?>

<!-- Offset Section -->		
		<section></section>
</div>
<?php get_footer(); ?>
