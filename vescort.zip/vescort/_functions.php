<?php
add_action( 'after_setup_theme', 'vescort_setup' );
function vescort_setup(){
	load_theme_textdomain( 'vescort', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	global $content_width;
	if ( ! isset( $content_width ) ) $content_width = 640;
	register_nav_menus(
		array( 'main-menu' => __( 'Main Menu', 'vescort' ) )
	);
}
add_action( 'wp_enqueue_scripts', 'vescort_load_scripts' );
function vescort_load_scripts(){
	//css
	wp_enqueue_style( 'foundation', get_template_directory_uri() . '/css/foundation.min.css');
	wp_enqueue_style( 'navTemplate', get_template_directory_uri() . '/css/navTemplate.css');
	wp_enqueue_style( 'margin-padding', get_template_directory_uri() . '/css/marginPadding.css');
	wp_enqueue_style( 'animation', get_template_directory_uri() . '/css/animate.css');
	//wp_enqueue_style( 'bxslider', get_template_directory_uri() . '/css/bxslider.min.css');
	wp_enqueue_style( 'app', get_template_directory_uri() . '/css/app.css');
	//fonts
	wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css?family=Open+Sans');
	//js
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'foundation', get_template_directory_uri() . '/js/foundation.min.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'navTemplate', get_template_directory_uri() . '/js/navTemplate.js', array('jquery'), '1.0.0', true );
	//wp_enqueue_script( 'bxslider', get_template_directory_uri() . '/js/jquery.bxslider.min.js?ver=1.0.0', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'app', get_template_directory_uri() . '/js/app.js', array('foundation'), '1.0.0', true );
	wp_enqueue_script( 'tweenmax', get_template_directory_uri() . '/js/TweenMax.min.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'scrollex', get_template_directory_uri() . '/js/jquery.scrollex.min.js', array('jquery'), '1.0.0', true );
}
add_action( 'comment_form_before', 'vescort_enqueue_comment_reply_script' );
function vescort_enqueue_comment_reply_script(){
	if ( get_option( 'thread_comments' ) ) { wp_enqueue_script( 'comment-reply' ); }
}
add_filter( 'the_title', 'vescort_title' );
function vescort_title( $title ) {
	if ( $title == '' ) {
		return '&rarr;';
	} 
	else {
		return $title;
	}
}
add_filter( 'wp_title', 'vescort_filter_wp_title' );
function vescort_filter_wp_title( $title ){
	return $title . esc_attr( get_bloginfo( 'name' ) );
}
add_action( 'widgets_init', 'vescort_widgets_init' );
function vescort_widgets_init(){
	register_sidebar( 
		array (
			'name' => __( 'Sidebar Widget Area', 'vescort' ),
			'id' => 'primary-widget-area',
			'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
			'after_widget' => "</li>",
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>',
		) 
	);
}
function vescort_custom_pings( $comment ){
	$GLOBALS['comment'] = $comment;
	?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>"><?php echo comment_author_link(); ?></li>
	<?php 
}
add_filter( 'get_comments_number', 'vescort_comments_number' );
function vescort_comments_number( $count ){
	if ( !is_admin() ) {
		global $id;
		$comments_by_type = &separate_comments( get_comments( 'status=approve&post_id=' . $id ) );
		return count( $comments_by_type['comment'] );
	} 
	else {
		return $count;
	}
}

add_action( 'loop_start', 'using_front_page_conditional_tag' );
function using_front_page_conditional_tag() {
if ( is_front_page() ) {	
/*
****************** 
Test function

	echo'<h2>Only Displays On The Front Page</h2>';

*/
    }
}