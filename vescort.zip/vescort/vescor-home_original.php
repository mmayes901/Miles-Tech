<?php /* Template Name: Vescor Original Home template */ ?>
<?php 
		$x = get_field('home_hero_call_to_action');
		$who_we_are_text = get_field('who_we_are_text');
?>
<?php get_header(); ?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<!-- Who We Are Section  -->
		<section id="elements" class="padT60 padB60">
				<div class="row">
					
					<div class="medium-4 columns">
						<h2 class="callToAction"><?php echo $x; ?></h2>
							<?php echo $who_we_are_text; ?>
					</div>
					<div class="medium-8 columns">
						<img src="wp-content/uploads/2017/03/rdt.png">
					</div>
					
				</div>
		</section>


<!--Our Partners Section  -->

		<section>
			<div class="row partner wrapper">
				<div class="row">
					<div class="medium-4 columns" style="padding-left: 120px; margin: 20px;"> 
						<h2 class="callToAction"> OUR PARTNERS </h2>
						<p>&nbsp;</p>
					</div>
				</div>

				<div class="medium-3 columns"> _</div>
				<div class="medium-3 columns"><img src="wp-content/uploads/2017/03/MDA-logo-300x106.png"></div>
				<div class="medium-6 columns"> <img src="wp-content/uploads/2017/03/deerfield-logo-white-300x97.png"></div>
				<div class="row">
					<p>&nbsp;</p>
					<div class="small-12 columns" style="text-align: center;"><button type="button" class=" hollow button">FIND OUT MORE</button></div>
				</div>

			</div>
		</section>

<!-- What we Do Section  -->

		<section id="elements" class="padT60 padB60">
				<div class="row">
					
					<div class="medium-4 columns">
						<img src="wp-content/uploads/2017/03/microscope.png">
					</div>
					<div class="medium-4 columns">
						<img src="wp-content/uploads/2017/03/pink-cells.png">
					</div>
					<div class="medium-4 columns">
						<h2 class="callToAction">WHAT WE DO</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla dictum dolor id scelerisque venenatis. Aliquam erat volutpat. Donec semper, risus vel dapibus varius, nisi nisi congue tellus, ultricies ultrices elit sapien nec lorem.</p>

							<p>Etiam a magna sed nisi finibus rutrum. Vivamus tempus nulla sed aliquam malesuada. Vestibulum vel feugiat augue. Vivamus gravida vel nunc vel elementum.  Ut tempus scelerisque ante, eu imperdiet sem ornare vitae. Integer at justo vitae magna faucibus auctor quis sed augue. Sed ac elementum lectus. Quisque ornare laoreet magna, quis commodo urna sagittis sit amet.</p>
					</div>
				</div>
		</section>
		
	<?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>
