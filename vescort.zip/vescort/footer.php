
<!-- How Can We Make A Difference -->
	<?php if ( !is_front_page() ) {	

		echo '<section class="helper padT60 padB60">
			<div class="row">
				<div class="large-12 columns mobileCenter" style="margin: 0 auto;"">
			    	<p class="h1 caps black text-wrap text-center wbg">How Can You Make A Difference?</p>
			    </div>
			 </div>
			<div class="row">
			    <div class="large-12 columns mobileCenter">
			    	<p></p>
					<p class="text-center" style="margin:0 auto;">
					<button type="button" class="hollow button">FIND OUT MORE</button>
					</p>
				</div>
			</div>
		</section>';
	} ?>				
		
			<footer class="bgDGray white padT20 padB20 footer" role="contentinfo">
			<div class="row"  data-equalizer="contactus">
				<div class="content_block" id="custom_post_widget-298">
					<div class="large-4 columns mobileCenter" data-equalizer-watch="contactus">
						<p class="h6 white caps padT padB">LOCATION:</p>
						<p class="white">Vescor Therapeutics, LLC.<br />
						780 Third Ave<br />
						New York, New York 10017</p>
					</div>
				<div class="large-4 columns mobileCenter" data-equalizer-watch="contactus">
					<p class="h6 white caps padT padB">CONTACT:</p>
					Karen Heidelberger<br />
					<p<a class="white whiteUnderline" href="#" class="white whiteUnderline">info@vescortherapeutics.com</a></p>

				</div>
				<div class="large-4 columns mobileCenter text-right" data-equalizer-watch="contactus">
					<p class="h6 white caps padT padB">QUICK LINKS:</p>
						<ul>
							<li><a href="/pipeline/" class="white whiteUnderline">Pipeline</a></li>
							<li><a href="/about-us/" class="white whiteUnderline">About Us</a></li>
							<li><a href="/our-partners/" class="white whiteUnderline">Our Partners</a></li>
							<li><a href="/news/" class="white whiteUnderline">News</a></li>
							<li><a href="/contact-us/" class="white whiteUnderline">Contact Us</a></li>
						</ul>
					</div>
				</div>
		</div>
				<div class="row">
			    	<div class="large-12 columns text-center">
			        	<div id="copyright">
			        		<?php echo bloginfo ( name ) ?> &copy  <?php echo date('Y') ?>. All Rights Reserved. Responsive Website by <a href="https://www.milestechnologies.com/" rel="nofollow" target="_blank" class="white whiteUnderline">MilesTechnologies.com</a> | <a href="/sitemap" class=" white whiteUnderline">Sitemap</a>
			        	</div>
			        </div>
			    </div>
			</footer>
		</div>
		<?php wp_footer(); ?>
	</body>
</html>