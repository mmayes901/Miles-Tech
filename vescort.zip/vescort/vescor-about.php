<?php /* Template Name: Vescor about template */ ?>
<?php get_header(); ?>
<?php 
		$first_title = get_field('first_title', $post->ID);
		$first_section_text = get_field('first_section_text', $post->ID);
		$first_image = get_field('first_image', $post->ID);
		$first_alt_text = get_field('first_alt_text', $post->ID);
?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>
<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>

<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section>
			<div class="row animated zoomIn">
				<div class="large-12 columns">
			    	<h1 class="pgtitle"><?php the_title(); ?></h1>
			    </div>
		    </div>
		</section>

<!-- Offset Section -->		
		<section></section>

<!-- Content Section UnShaded  -->
		<section id="about1" class="padT60 padB60">
				<div class="row" data-equalizer="about1">
					
					<div class=" medium-9 columns" data-equalizer-watch="about1">
						<h5><?php the_field('first_title'); ?></h5>
						<?php the_field('first_section_text'); ?>
					 
					</div>
					<div class=" medium-3 columns">
						<img src="<?php the_field('first_image'); ?>" alt="<?php the_field('first_alt_text') ?>">
					</div>
	
				</div>
		</section>

<!-- Content Section Shaded  -->
		<section id="about2" class="padT60 padB60">
				<div class="row" data-equalizer="about2">
					
					<div class=" medium-3 columns" data-equalizer-watch="about2">
						<img src="<?php the_field('second_image'); ?>" alt="<?php the_field('second_alt_text') ?>">
					</div>
					<div class=" medium-9 columns" data-equalizer-watch="about2">
							<h5><?php the_field('second_title'); ?>	</h5>	
								<?php the_field('second_section_text'); ?>
					</div>
	
				</div>
		</section>

<!-- Content Section UnShaded  -->
		<section id="about3" class="padT60 padB60">
				<div class="row" data-equalizer="about3">
					
					<div class=" medium-9 columns" data-equalizer-watch="about3">
							<h5><?php the_field('third_title'); ?></h5>		
							<?php the_field('third_section_text'); ?>
					</div>
	
					<div class=" medium-3 columns" data-equalizer-watch="about3">
						<img src="<?php the_field('third_image'); ?>" alt="<?php the_field('third_alt_text') ?>">
					</div>
	
				</div>
		</section>

<!-- Content Section Shaded  -->
		<section id="about4" class="padT60 padB60">
				<div class="row" data-equalizer="about4">
					
					<div class=" medium-3 columns" data-equalizer-watch="about4">
						<img src="<?php the_field('fourth_image'); ?>" alt="<?php the_field('fourth_alt_text') ?>">
					</div>
					<div class=" medium-9 columns" data-equalizer-watch="about4">
							<h5><?php the_field('fourth_title'); ?></h5>
							<?php the_field('fourth_section_text'); ?>
					</div>
	
				</div>
		</section>

<!-- Content Section UnShaded  -->
		<section id="about5" class="padT60 padB60">
				<div class="row" data-equalizer="about5">
					
					<div class=" medium-9 columns" data-equalizer-watch="about5">
							<h5><?php the_field('fifth_title'); ?></h5>
							<?php the_field('fifth_section_text'); ?>
					</div>
	
					<div class=" medium-3 columns" data-equalizer-watch="about5">
						<img src="<?php the_field('fifth_image'); ?>" alt="<?php the_field('fifth_alt_text') ?>">
					</div>
	
				</div>
		</section>
<!-- Content Section Shaded  -->
		<section id="about6" class="padT60 padB60">
				<div class="row" data-equalizer="about6">
					
					<div class=" medium-3 columns" data-equalizer-watch="about6">
						<img src="<?php the_field('six_image'); ?>" alt="<?php the_field('six_alt_text') ?>">
					</div>
					<div class=" medium-9 columns" data-equalizer-watch="about6">
							<h5><?php the_field('six_title'); ?></h5>
							<?php the_field('six_section_text'); ?>
					</div>
	
				</div>
		</section>

<!-- Content Section UnShaded  -->
		<section id="about7" class="padT60 padB60" style="height: 100%;">
				<div class="row" data-equalizer="about7">
					
					<div class=" medium-9 columns" data-equalizer-watch="about7">
							<h5><?php the_field('seven_title'); ?></h5>
							<?php the_field('seven_section_text'); ?>
					</div>
	
					<div class=" medium-3 columns" data-equalizer-watch="about7">
						<img src="<?php the_field('seven_image'); ?>" alt="<?php the_field('seven_alt_text') ?>">
					</div>
	
				</div>
		</section>

<!-- Offset Section -->		
		<section></section>
</div>
<?php get_footer(); ?>
