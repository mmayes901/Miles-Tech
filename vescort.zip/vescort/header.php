<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="icon" rel="http://vescortx.nextmp.net/wp-content/uploads/2017/03/favicon.png" type="image/png" sizes="32x32">
		<link rel="icon" rel="http://vescortx.nextmp.net/wp-content/uploads/2017/03/favicon.png" type="image/png" sizes="192x192">
		<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_uri(); ?>" />
		<?php wp_head(); ?>		
	</head>
	<body <?php body_class(); ?> >
		<div id="wrapper" class="hfeed">

		<!-- Header -->
		
				<header role="banner" class="sticky"">

				<div class="row collapse sameheight-nav-wrap">
			    	<div class="columns large-4 text-center sameheight-nav">
			        	
			        	<a href="/" class="logo"><img src="<?php bloginfo('template_directory'); ?>/imgs/vescor_logo.png" alt="Vescor Therapeutics logo" border="0" style="max-width:175px;"></a>
			        	
			        </div>
			        <div class="columns large-8 sameheight-nav">
			        	<nav id="menu" role="navigation">
							<div class="navContainer">
								<div class="navTemplateControl">
									<div class='menuText'>Menu</div>
									<div class='menuButton'>
										<div class='line1'></div>
										<div class='line2'></div>
										<div class='line3'></div>
									</div>
								</div>
								<?php wp_nav_menu( array( 'theme_location' => 'main-menu', 'menu_class' => 'navTemplate' ) ); ?>
							</div>
						</nav>
					</div>
				</div>
			</header>
			
