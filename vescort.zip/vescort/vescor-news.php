<?php /* Template Name: Vescor News template */ ?>
<?php get_header(); ?>
<?php 
		$first_title = get_field('first_title', $post->ID);
		$first_section_text = get_field('first_section_text', $post->ID);
		$first_image = get_field('first_image', $post->ID);
		$first_alt_text = get_field('first_alt_text', $post->ID);
?>
<div id="content" role="main" post-id="<?php the_ID(13); ?>" <?php post_class(); ?>>
<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>

<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section>
			<div class="row animated zoomIn">
				<div class="large-12 columns">
			    	<h1 class="pgtitle"><?php the_title(); ?></h1>
			    </div>
		    </div>
		</section>

<!-- Offset Section -->		
		<section></section>

<!-- Content Section UnShaded  -->
		<section class="padT60 padB60">
				<div class="row">
					<div class="columns large-8 mediaCenter">
						<h2 class="entry-title">MD Anderson and Deerfield Management create Vescor LLC to develop novel therapeutics based on
						inhibiting autophagy for treatment of specific cancers</h2>

						<p><strong>HOUSTON and NEW YORK, Jan. 11, 2017</strong> /PRNewswire/ ‐‐ Vescor LLC, a new company focused on
						discovery and development of autophagy targeted therapeutics for cancer treatment, has been formed
						by <a href="https://www.mdanderson.org/" target="_blank">The University of Texas MD Anderson Cancer Center</a>, Deerfield Management and two leading
						autophagy experts, Eileen White, Ph.D., deputy director and associate director for Basic Science, Rutgers
						Cancer Institute of New Jersey, and Alec Kimmelman, M.D., Ph.D., chairman, Department of Radiation
						Oncology at NYU Langone Medical Center and a member of the Perlmutter Cancer Center at NYU
						Langone.</p>

						<p>Vescor, advised by its scientific founders White and Kimmelman, whose research has shown inhibition
						of autophagy can dramatically impact tumor growth in pre‐clinical models, will develop small molecule
						inhibitors of a number of protein targets at critical nodes of the autophagy cascade, perform
						investigational new drug (IND) enabling studies, and move these into clinical development. MD
						Anderson's <a href="https://www.mdanderson.org/cancermoonshots/research_platforms/Institute_for_applied_cancer_science.html" target="_blank">Institute for Applied Cancer Science</a> (IACS) in combination with Deerfield will provide drug
						discovery and development expertise, together with translational research focused at advancing
						autophagy therapeutics into trials in melanoma, lung and pancreatic cancers.</p>

						<p>Autophagy is a cellular process that plays an important role during the development and maintenance of
						tumors, providing them with the metabolic plasticity to meet their energetic needs, and requirements
						for cellular building blocks. It allows tumors to scavenge nutrients to sustain growth and survival.
						Autophagy also has been demonstrated as critical to therapeutic resistance, and is upregulated during
						cancer treatment in response to chemotherapy and radiation.</p>   

						<p>"Nutrient scavenging by autophagy is a process that tumors hijack to meet their energetic requirements
						and to provide the necessary cellular building blocks for growth in a stressed tumor micro‐
						environment," said White. "Preclinical models have demonstrated a critical role for autophagy in
						multiple cancer types."</p>

						<p>Autophagy has been known for over 50 years but its fundamental importance in physiology and
						medicine was only recognized after Yoshinori Ohsumi's paradigm‐shifting research in the 1990's that
						allowed the detailed study of the process for which he was awarded this year's Nobel Prize in physiology
						or medicine.</p>

						<p>"Numerous pre‐clinical studies have now shown a requirement for autophagy in sustaining tumor
						growth, including pancreatic cancer, as well as in providing a mechanism of resistance to a number of
						currently used therapies," said Kimmelman. "There is a need for potent and specific autophagy
						inhibitors to advance these important findings into clinical practice."</p>

						<p>In creating Vescor, Deerfield and MD Anderson aim to perform drug discovery and development in a
						markedly different way than traditional oncology start‐ups. Core activities will be performed at IACS,
						which provides deep drug discovery and translational research expertise and capabilities, while
						managerial and operational expertise is provided by both IACS and Deerfield.</p>

						<p>"We are excited to join forces with Drs. White and Kimmelman, two world‐leading autophagy experts,"
						said Phil Jones, Ph.D., IACS's executive director and head of drug discovery. "Our goal is to drive novel
						drug discovery paradigms and develop cancer therapeutics targeting unexplored mechanisms that might
						provide high clinical impact. We are delighted to partner in this effort to advance novel drugs towards
						the clinic."</p>

						<p>Vescor's goal is to generate at least one IND‐ready asset in a condensed timeframe. This capital‐efficient
						model is possible due to the availability of 100 percent of dedicated resources advancing product
						development efforts.</p>

						<p>"We believe Vescor will identify opportunities to significantly advance the treatment of cancer through
						manipulating autophagy and thus restore cellular homeostasis leading to the potential reduction of
						cancer disease burden," stated William Slattery, Partner at Deerfield. "We look forward to working with
						Drs. White and Kimmelman and MD Anderson to expedite the novel biology of autophagy and
						to develop drugs that have the ability to impact the lives of patients."</p>

						<strong>About Deerfield</strong>
						<br />
						Deerfield is an investment management firm committed to advancing healthcare through investment,
						information and philanthropy.
						<p></p>
						<strong>About MD Anderson</strong>
						<br />
						<a href="https://www.mdanderson.org/" target="_blank">The University of Texas MD Anderson Cancer Center</a> in Houston ranks as one of the world's most
						respected centers focused on cancer patient care, research, education and prevention. The institution's
						sole mission is to end cancer for patients and their families around the world. MD Anderson is one of
						only 45 comprehensive cancer centers designated by the National Cancer Institute (NCI). MD Anderson
						is ranked No.1 for cancer care in U.S. News & World Report's "Best Hospitals" survey. It has ranked as
						one of the nation's top two hospitals since the survey began in 1990, and has ranked first for nine of the
						past 10 years. MD Anderson receives a cancer center support grant from the NCI of the National
						Institutes of Health (P30 CA016672).

						<p><a href="#" target="_blank">Follow MD Anderson News on Twitter</a></p>
						<strong>Contacts:</strong>                 
						<br />
						<strong>MD Anderson</strong>
						<br />
						Ron Gilmore
						<br />
						713‐745‐1898
						<br />
						<a href="mailto:rlgilmore1@mdanderson.org">rlgilmore1@mdanderson.org</a>

						<p></p>
						<strong>Deerfield Management</strong>
						<br />
						Karen Heidelberger
						<br />
						212‐692‐7140
						<br />
						<a href="mailto:karenh@deerfield.com">karenh@deerfield.com</a>
					</div> <!-- Column -->
					<div columns large-4>
						<h5 class="posts-title text-center center-column">Recent Posts</h5>
						<p></p>
					</div>
				</div> <!-- row -->
		</section>

<!-- Offset Section -->		
		<section></section>
</div>
<?php get_footer(); ?>
