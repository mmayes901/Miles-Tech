<?php /* Template Name: Vescor Home template */ ?>


<!-- Advance Custom Fields variables  -->

<?php 
		$x = get_field('home_hero_call_to_action');
		$who_we_are_text = get_field('who_we_are_text');
		$who_we_are_graphic = get_field('who_we_are_graphic');
		$who_we_are_alt_text = get_field('who_we_are_alt_text');
		$our_partners_text = get_field('our_partners_text');
		$partner_logo_1 = get_field('partner_logo_1');
		$p_logo_1_alt = get_field('p_logo_1_alt');
		$partner_logo_2 = get_field('partner_logo_2');
		$p_logo_2_alt = get_field('p_logo_2_alt');
		$wgraphic1 = get_field('wgraphic1');
		$wgraphic1_alt = get_field('wgraphic1_alt');
		$wgraphic2 = get_field('wgraphic2');
		$wgraphic2_alt = get_field('wgraphic2_alt');
		$what_we_do_text = get_field('what_we_do_text');
		$what_we_do_para = get_field('what_we_do_para');

?>

<!-- Header -->
<?php get_header(); ?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

			<!-- Content-->
			<section>
				<div class="row">
					<div class="columns medium-12">
				     </div>
			    </div>
			</section>




			<?php if ( is_front_page() ) {	
				echo '<div class="scientistBg">
							<div class="row animated fadeInLeft">
		 						<div class="small-12 columns mobileCenter">
				 				 	<h2 class="caps black wbgl">Developing Cancer Therapeutics</h2>
				          	    </div>
				          	</div>
				          	<div class="row animated fadeInRight">
				          	   	<div class="medium-12 columns mobileCenter">
				 				 	<h2 class="caps black wbgr">Targeting Unexplored mechanisms</h2>
				         	   </div>
				   		    </div> 
		       			</div>'; 
		    } ?>

 </div>

<!-- Who We Are Section  -->
		<section id="who">
				<div class="row">
					
					<div class="medium-4 columns mobileCenter PadB20">
						<h2 class="callToAction caps"><?php echo $x; ?></h2>
							<?php echo $who_we_are_text; ?>
					</div>
					<div class="medium-8 columns mobileCenter  MarginB50">
						<img src="<?php echo $who_we_are_graphic; ?>" alt="<?php echo $who_we_are_alt_text; ?>">
					</div>
					
				</div>
		</section>


<!--Our Partners Section  -->

		<section id="partners" class="partner">
			<div class="row padT60 padB60">
					<div class="medium-5 columns mobileCenter"> 
						<h2 class="callToAction caps"> <?php echo $our_partners_text; ?> </h2>	 
					</div>
				</div>

				<div class="row text-center mobileCenter" data-equalizer="partner">
					<div class="medium-6 columns" data-equalizer-watch="partner" style="text-align: right;"><img src="<?php echo $partner_logo_1; ?>" alt="<?php echo $p_logo_1_alt; ?>"></div>
					<div class="medium-6 columns mobileCenter" data-equalizer-watch="partner" style="text-align: left;"> <img src="<?php echo $partner_logo_2; ?>" alt="<?php echo $p_logo_2_alt; ?>"></div>
				</div>

				<div class="row PadT30 PadB60">
					<div class="large-12 columns text-center mobileCenter"><button type="button" class=" hollow button">FIND OUT MORE</button></div>
			</div>
		</section>

<!-- What we Do Section  -->

		<section id="whatWeDo" class="padT60 padB40">
				<div class="row" data-equalizer="what">
					
					<div class="medium-4 columns mobileCenter PadB20" data-equalizer-watch="what">
						<img id="home-image-1" src="<?php echo $wgraphic1; ?>" alt="<?php echo $wgraphic1_alt; ?>">
					</div>
					<div class="medium-4 columns mobileCenter hide-for-small-only PadB20" data-equalizer-watch="what">
						<img src="<?php echo $wgraphic2; ?>" alt="<?php echo $wgraphic2_alt; ?>">
					</div>
					<div class="medium-4 columns mobileCenter PadB20" data-equalizer-watch="what">
						<h2 class="callToAction caps"><?php echo $what_we_do_text; ?></h2>
						<?php echo $what_we_do_para; ?>
					</div>
				</div>
		</section>
		
	<?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>
