<?php /* Template Name: Vescor partners template */ ?>
<?php get_header(); ?>
<?php 
?>
<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>

<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>
<!-- Offset Section -->		
		<section></section>


<!-- Page Title  -->
	 	<section>
			<div class="row animated zoomIn">
				<div class="large-12 columns">
					<div class="slideContent">
				      <div class="content_block" id="custom_post_widget-265">

			    			<h1 class="pgtitle"><?php the_title(); ?></h1>
			    	   </div>
		    		</div>
		    	</div>
		    </div>
		</section>

<!-- Offset Section -->		
		<section></section>


<!-- Content Section UnShaded  -->
		<section id="opartners1" class="padT60 padB60">
				<div class="row" data-equalizer="opartners1">
					<div class=" medium-9 columns" data-equalizer-watch="opartners1">
						<?php the_field('partner_info'); ?>
					</div>
					<div class=" medium-3 columns" data-equalizer-watch="opartners1">
						<a href="<?php the_field('partner_url'); ?>" target="_blank" class="white whiteUnderline"><img src="<?php the_field('partner_logo'); ?>" alt="<?php the_field('partner_alt_text') ?>"></a>
					</div>
	
				</div>
		</section>

<!-- Content Section Shaded  -->
		<section id="opartners2" class="padT60 padB60">
				<div class="row" data-equalizer="opartners2">
					<div class=" medium-9 columns" data-equalizer-watch="opartners2">
						<?php the_field('partner2_info'); ?>
					</div>
					<div class=" medium-3 columns" data-equalizer-watch="opartners2">
						<a href="<?php the_field('partner2_url'); ?>" target="_blank" class="white whiteUnderline"><img src="<?php the_field('partner2_logo'); ?>" alt="<?php the_field('partner2_alt_text') ?>"></a>
					</div>
	
				</div>
		</section>

</div>
<?php get_footer(); ?>
