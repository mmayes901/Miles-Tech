(function($) {
	//initialize foundation
	$(document).foundation();

	$(function() {
	 $('#who').scrollex({

   			// add some padding to the viewpoint
	    	top: '50px',

			enter: function() {
			
			// Slide figures in horizontally upon entering into who we are section.
			      TweenMax.to("#who", 0.618, {opacity:1, x:0, delay:0.982});
			}

	 }); // Close who scrollex

	  $('#partners').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#partners", 0.618, {opacity:1, y:0, delay:0.382});

	    	}
	  }); // Close our partners scrollex

	  $('#whatWeDo').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#whatWeDo", 0.618, {opacity:1, y:0, delay:0.382});

	    	}
	  }); // Close what we do scrollex

// About us page

	 $('#about1').scrollex({

   			// add some padding to the viewpoint
	    	top: '50px',

			enter: function() {
			
			// Slide figures in horizontally upon entering into who we are section.
			      TweenMax.to("#about1", 0.618, {opacity:1, x:0, delay:0.382});
			}

	 }); // Close about us scrollex



	  $('#about2').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#about2", 0.618, {opacity:1, x:0, delay:0.482});

	    	}
	  }); // Close about us 2 scrollex

	  $('#about3').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#about3", 0.618, {opacity:1, x:0, delay:0.382});

	    	}
	  }); // Close about us 3 scrollex

	  $('#about4').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#about4", 0.618, {opacity:1, x:0, delay:0.382});

	    	}
	  }); // Close about us 4 scrollex

	  $('#about5').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#about5", 0.618, {opacity:1, x:0, delay:0.382});

	    	}
	  }); // Close about us 5 scrollex

	  $('#about6').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#about6", 0.618, {opacity:1, x:0, delay:0.382});

	    	}
	  }); // Close about us 6 scrollex

	  $('#about7').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#about7", 0.618, {opacity:1, x:0, delay:0.382});

	    	}
	  }); // Close about us 7 scrollex


	  $('#contactUs').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#contactUs", 0.618, {opacity:1, y:0, delay:0.382});

	    	}
	  }); // Close contact us 7 scrollex

	  $('#pipeline1').scrollex({

   			// add some padding to the viewpoint
	    	top: '50px',

			enter: function() {
			
			// Slide figures in horizontally upon entering into who we are section.
			      TweenMax.to("#pipeline1", 0.618, {opacity:1, x:0, delay:0.382});
			}

	 }); // Close who scrollex

	  $('#pipeline2').scrollex({

   			// add some padding to the viewpoint
	    	top: '50px',

			enter: function() {
			
			// Slide figures in horizontally upon entering into who we are section.
			      TweenMax.to("#pipeline2", 0.618, {opacity:1, x:0, delay:0.482});
			}

	 }); // Close who scrollex

	  $('#opartners1').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#opartners1", 0.618, {opacity:1, y:0, delay:0.382});

	    	}
	  }); // Close Our partner 1 scrollex

	  $('#opartners2').scrollex({
	    	
	    	// add some padding to the viewpoint
	    	top: '50px',

		    enter: function() {

		    // Slide figures in vertically upon entering what we do section.
	      		TweenMax.to("#opartners2", 0.618, {opacity:1, y:0, delay:0.382});

	    	}
	  }); // Close Our Partners 2 scrollex






	}); // Close scrollex function

})( jQuery );