<?php get_header(); ?>

<div id="content" role="main" post-id="<?php the_ID(); ?>" <?php post_class(); ?>>
<!-- Display menu Background  -->
<?php  
include('menubg.php'); 
?>

<!-- Offset Section -->		
		<section></section>

<section class="entry-content">
	<p></p>
	<div class="row padT60 padB60">
	
		<div class=" large-12 columns mobileCenter" style="margin: 0 auto;">
		<p class="text-center">
			<img src="/wp-content/uploads/2017/03/404-error-page-300x169.png">
		</p>
		<h5 class="large-12 columns ext-wrap text-center mobileCenter" style="margin: 0 auto;">Sorry but the page you are looking for has changed or does not exist.</h>
		</div>
	</div>

</section>
<?php get_footer(); ?>